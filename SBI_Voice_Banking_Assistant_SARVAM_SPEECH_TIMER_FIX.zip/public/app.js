const langEl = document.getElementById("language");
const mic = document.getElementById("mic");
const statusEl = document.getElementById("status");
const transcriptEl = document.getElementById("transcript");
const responseEl = document.getElementById("response");
const errorEl = document.getElementById("error");
const form = document.getElementById("askForm");
const input = document.getElementById("textInput");
const chips = document.getElementById("chips");
const supportStatus = document.getElementById("supportStatus");

// ISO/browser language codes for the 22 scheduled Indian languages + English.
// Browser SpeechRecognition/SpeechSynthesis support varies by installed browser/OS voice pack.
const speechCodes = {
  hi:"hi-IN", en:"en-IN", as:"as-IN", bn:"bn-IN", brx:"brx-IN", doi:"doi-IN",
  gu:"gu-IN", kn:"kn-IN", ks:"ks-IN", kok:"kok-IN", mai:"mai-IN", ml:"ml-IN",
  mni:"mni-IN", mr:"mr-IN", ne:"ne-NP", or:"or-IN", pa:"pa-IN", sa:"sa-IN",
  sat:"sat-IN", sd:"sd-IN", ta:"ta-IN", te:"te-IN", ur:"ur-IN"
};

const languageNames = {
  hi:"Hindi", en:"English", as:"Assamese", bn:"Bengali", brx:"Bodo", doi:"Dogri",
  gu:"Gujarati", kn:"Kannada", ks:"Kashmiri", kok:"Konkani", mai:"Maithili",
  ml:"Malayalam", mni:"Manipuri", mr:"Marathi", ne:"Nepali", or:"Odia", pa:"Punjabi",
  sa:"Sanskrit", sat:"Santali", sd:"Sindhi", ta:"Tamil", te:"Telugu", ur:"Urdu"
};

const examples = {
  hi:["मेरा balance कितना है?","मेरा UPI payment pending है","मेरा ATM card खो गया","नजदीकी ATM कहाँ है?","बैंक कब तक खुला रहेगा?","शनिवार को बैंक खुला रहता है?","दूसरे शनिवार को बैंक बंद है?","आज बैंक खुला है?","बैंक में lunch time क्या है?","account में maximum कितना balance रख सकता हूँ?","मेरा account number बताओ","mini statement दिखाओ","KYC कैसे update करूं?","मेरा पैसा कट गया लेकिन सामने वाले को नहीं मिला","ATM ने पैसा नहीं दिया लेकिन account से कट गया","चेक बाउंस हो गया","NEFT कैसे करें?","आधार लिंक करना है","मेरा mobile number बदलना है","मेरा card खो गया है","fake SMS आया है","passbook update कैसे करूं?","account बंद कैसे करें?"],
  en:["What is my balance?","My UPI payment is pending","My debit card is lost","Where is the nearest ATM?","When does the bank close?","Is the bank open on Saturday?","Is the bank closed on the second Saturday?","Is the bank open today?","What is the bank lunch time?","How much balance can I keep?","Tell me my account number","Show mini statement","How do I update KYC?","Money was debited but receiver did not get it","ATM did not dispense cash but account was debited","My cheque bounced","How to do NEFT?","How to link Aadhaar?","How to change my mobile number?","How do I close my account?","I received a fake SMS"]
};

let mediaRecorder = null;
let mediaStream = null;
let audioChunks = [];
let audioContext = null;
let analyser = null;
let silenceFrame = null;
let silenceStartedAt = 0;
let speechDetected = false;
let noSpeechTimer = null;
let maxRecordingTimer = null;
let playbackAudio = null;
let requestSerial = 0;
let activeRequestId = 0;
let activeController = null;
let micState = "IDLE"; // IDLE -> RECORDING -> PROCESSING -> SPEAKING -> IDLE

const sarvamTtsLanguages = new Set(["hi", "en", "bn", "gu", "kn", "ml", "mr", "or", "pa", "ta", "te"]);

function setStatus(text) { statusEl.textContent = text; }

function getVoices() {
  return ("speechSynthesis" in window) ? window.speechSynthesis.getVoices() : [];
}

function pickVoice(lang) {
  const voices = getVoices();
  const code = (speechCodes[lang] || "hi-IN").toLowerCase();
  return voices.find(v => (v.lang || "").toLowerCase() === code)
    || voices.find(v => (v.lang || "").toLowerCase().startsWith(code.split("-")[0]))
    || voices.find(v => (v.lang || "").toLowerCase() === "en-in")
    || voices.find(v => (v.lang || "").toLowerCase().startsWith("en"))
    || voices[0]
    || null;
}

async function speak(text, requestId) {
  if (requestId !== activeRequestId) return;

  if (playbackAudio) {
    try { playbackAudio.pause(); playbackAudio.currentTime = 0; } catch (_) {}
    playbackAudio = null;
  }

  // Sarvam Bulbul v3 supports 11 languages. For the remaining UI languages,
  // keep the existing browser fallback rather than silently speaking another language.
  if (sarvamTtsLanguages.has(langEl.value)) {
    try {
      micState = "SPEAKING";
      setStatus("Generating voice...");
      const res = await fetch("/api/text-to-speech", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          text:String(text),
          language:langEl.value,
          speaker:"shubh",
          pace:1
        })
      });
      const data = await res.json();
      if (requestId !== activeRequestId) return;
      if (!res.ok) throw new Error(data.error || "Sarvam TTS request failed");
      if (data.supported === false) throw new Error(data.message || "Sarvam TTS does not support this language");
      if (!data.audioBase64) throw new Error("Sarvam TTS returned no audio");

      const binary = atob(data.audioBase64);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      const blob = new Blob([bytes], {type:data.mimeType || "audio/mpeg"});
      const audioUrl = URL.createObjectURL(blob);
      const audio = new Audio(audioUrl);
      playbackAudio = audio;
      audio.onplay = () => setStatus("Speaking...");
      audio.onended = () => {
        URL.revokeObjectURL(audioUrl);
        if (playbackAudio === audio) playbackAudio = null;
        if (requestId === activeRequestId) {
          micState = "IDLE";
          setStatus("Ready for your next question");
        }
      };
      audio.onerror = () => {
        URL.revokeObjectURL(audioUrl);
        if (playbackAudio === audio) playbackAudio = null;
        if (requestId === activeRequestId) {
          errorEl.textContent = "Sarvam voice audio could not be played.";
          micState = "IDLE";
          setStatus("Ready for your next question");
        }
      };
      supportStatus.textContent = `Sarvam Bulbul v3 • ${languageNames[langEl.value]}`;
      await audio.play();
      return;
    } catch (err) {
      if (requestId !== activeRequestId) return;
      console.warn("Sarvam TTS unavailable; using browser fallback:", err.message);
    }
  }

  // Browser fallback for languages not currently supported by Bulbul v3 or
  // if the Sarvam request fails. This keeps typing and non-Sarvam languages usable.
  if (!("speechSynthesis" in window) || !("SpeechSynthesisUtterance" in window)) {
    supportStatus.textContent = "Sarvam TTS unavailable and browser TTS is not supported.";
    micState = "IDLE";
    setStatus("Ready for your next question");
    return;
  }

  const synth = window.speechSynthesis;
  synth.cancel();
  try { synth.resume(); } catch (_) {}
  const selected = speechCodes[langEl.value] || "hi-IN";
  const u = new SpeechSynthesisUtterance(String(text));
  u.lang = selected;
  u.rate = 0.92;
  u.pitch = 1;
  u.volume = 1;
  const voices = synth.getVoices();
  const voice = voices.find(v => (v.lang || "").toLowerCase() === selected.toLowerCase())
    || voices.find(v => (v.lang || "").toLowerCase().startsWith(selected.split("-")[0].toLowerCase()))
    || voices.find(v => (v.lang || "").toLowerCase() === "en-in")
    || voices.find(v => (v.lang || "").toLowerCase().startsWith("en"))
    || voices[0]
    || null;
  if (voice) {
    u.voice = voice;
    u.lang = voice.lang || selected;
  }
  supportStatus.textContent = `Browser TTS fallback • ${languageNames[langEl.value] || "Selected language"}`;
  micState = "SPEAKING";
  setStatus("Speaking...");
  const finish = () => {
    if (requestId !== activeRequestId) return;
    micState = "IDLE";
    setStatus("Ready for your next question");
  };
  u.onend = finish;
  u.onerror = (event) => {
    console.error("Speech synthesis error:", event.error);
    errorEl.textContent = "Voice response नहीं चल सकी।";
    finish();
  };
  setTimeout(() => {
    if (requestId !== activeRequestId) return;
    try { synth.speak(u); synth.resume(); } catch (_) { finish(); }
  }, 0);
}

async function ask(text, existingRequestId = null) {
  const clean = text.trim();
  if (!clean) return;

  const requestId = existingRequestId ?? (++requestSerial);
  activeRequestId = requestId;

  // The latest question owns the UI. Cancel/abort any older in-flight request
  // so an old response cannot overwrite a newer transcript/intent/answer.
  if (activeController) activeController.abort();
  activeController = new AbortController();
  window.speechSynthesis?.cancel();

  micState = "PROCESSING";
  errorEl.textContent = "";
  setStatus("Understanding...");

  try {
    const res = await fetch("/api/detect-intent", {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        transcript: clean,
        language: langEl.value,
        requestId
      }),
      signal: activeController.signal
    });
    const data = await res.json();
    if (requestId !== activeRequestId) return;
    if (!res.ok) throw new Error(data.error || "Server error");

    responseEl.textContent = data.responseText;
    speak(data.responseText, requestId);
  } catch (e) {
    if (e.name === "AbortError" || requestId !== activeRequestId) return;
    errorEl.textContent = e.message === "Failed to fetch"
      ? "Server से response नहीं मिला. Check that server is running."
      : "Request process नहीं हो सका. कृपया दोबारा कोशिश करें.";
    micState = "IDLE";
    setStatus("Error");
  } finally {
    if (requestId === activeRequestId) activeController = null;
  }
}


function stopRecording() {
  if (!mediaRecorder || mediaRecorder.state === "inactive") return;
  try { mediaRecorder.stop(); } catch (_) {}
}

function cleanupRecording() {
  if (silenceFrame) cancelAnimationFrame(silenceFrame);
  silenceFrame = null;
  if (noSpeechTimer) clearTimeout(noSpeechTimer);
  if (maxRecordingTimer) clearTimeout(maxRecordingTimer);
  noSpeechTimer = null;
  maxRecordingTimer = null;
  if (mediaStream) mediaStream.getTracks().forEach(track => track.stop());
  mediaStream = null;
  if (audioContext) {
    try { audioContext.close(); } catch (_) {}
  }
  audioContext = null;
  analyser = null;
  mic.classList.remove("listening");
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

function monitorSilence() {
  if (!analyser || micState !== "RECORDING") return;
  const data = new Uint8Array(analyser.fftSize);
  analyser.getByteTimeDomainData(data);
  let sum = 0;
  for (const value of data) {
    const normalized = (value - 128) / 128;
    sum += normalized * normalized;
  }
  const rms = Math.sqrt(sum / data.length);
  const now = performance.now();
  const threshold = 0.025;

  if (rms > threshold) {
    speechDetected = true;
    silenceStartedAt = 0;
  } else if (speechDetected) {
    if (!silenceStartedAt) silenceStartedAt = now;
    if (now - silenceStartedAt > 1200) {
      stopRecording();
      return;
    }
  }
  silenceFrame = requestAnimationFrame(monitorSilence);
}

async function startRecording() {
  if (micState !== "IDLE") return;
  if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
    errorEl.textContent = "This browser does not support microphone recording. Please use the latest Chrome or Edge.";
    return;
  }

  if (activeController) activeController.abort();
  activeController = new AbortController();
  const requestId = ++requestSerial;
  activeRequestId = requestId;
  window.speechSynthesis?.cancel();
  if (playbackAudio) {
    try { playbackAudio.pause(); } catch (_) {}
    playbackAudio = null;
  }

  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      audio:{channelCount:1, echoCancellation:true, noiseSuppression:true, autoGainControl:true}
    });
    const mimeType = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"]
      .find(type => MediaRecorder.isTypeSupported(type)) || "";
    mediaRecorder = mimeType ? new MediaRecorder(mediaStream, {mimeType}) : new MediaRecorder(mediaStream);
    audioChunks = [];
    speechDetected = false;
    silenceStartedAt = 0;
    micState = "RECORDING";
    mic.classList.add("listening");
    transcriptEl.textContent = "Listening...";
    errorEl.textContent = "";
    setStatus("Listening... बोलिए");
    supportStatus.textContent = "Sarvam Saaras v3 STT • recording";

    mediaRecorder.ondataavailable = event => {
      if (event.data?.size) audioChunks.push(event.data);
    };

    mediaRecorder.onstop = async () => {
      const blob = new Blob(audioChunks, {type:mediaRecorder.mimeType || mimeType || "audio/webm"});
      cleanupRecording();
      mediaRecorder = null;
      if (!blob.size) {
        micState = "IDLE";
        setStatus("Ready");
        errorEl.textContent = "No audio was captured. Please try again.";
        return;
      }

      micState = "PROCESSING";
      setStatus("Transcribing with Sarvam...");
      try {
        const audioBase64 = await blobToBase64(blob);
        const res = await fetch("/api/speech-to-text", {
          method:"POST",
          headers:{"Content-Type":"application/json"},
          body:JSON.stringify({
            audioBase64,
            mimeType:blob.type,
            language:langEl.value,
            requestId
          }),
          signal:activeController?.signal
        });
        const data = await res.json();
        if (requestId !== activeRequestId) return;
        if (!res.ok) {
          const message = typeof data.error === "string" ? data.error : (data.error?.message || JSON.stringify(data.error || data));
          throw new Error(message || "Sarvam STT request failed");
        }
        const text = String(data.transcript || "").trim();
        if (!text) throw new Error("Sarvam did not detect speech. Please try again.");
        transcriptEl.textContent = text;
        supportStatus.textContent = `Sarvam Saaras v3 • ${data.language_code || speechCodes[langEl.value] || langEl.value}`;
        await ask(text, requestId);
      } catch (e) {
        if (e.name === "AbortError" || requestId !== activeRequestId) return;
        console.error(e);
        errorEl.textContent = e.message || "Sarvam STT request failed.";
        micState = "IDLE";
        setStatus("Ready");
      } finally {
        if (requestId === activeRequestId) activeController = null;
      }
    };

    mediaRecorder.onerror = () => {
      cleanupRecording();
      mediaRecorder = null;
      micState = "IDLE";
      errorEl.textContent = "Microphone recording failed. Please try again.";
      setStatus("Ready");
    };

    // Stop after 5 seconds if the user never speaks, or after 20 seconds maximum.
    noSpeechTimer = setTimeout(() => {
      if (!speechDetected) stopRecording();
    }, 5000);
    maxRecordingTimer = setTimeout(() => stopRecording(), 20000);

    try {
      audioContext = new (window.AudioContext || window.webkitAudioContext)();
      const source = audioContext.createMediaStreamSource(mediaStream);
      analyser = audioContext.createAnalyser();
      analyser.fftSize = 2048;
      source.connect(analyser);
      monitorSilence();
    } catch (_) {
      // Silence detection is optional; manual stop and the 20s max timer still work.
    }

    mediaRecorder.start(250);
  } catch (e) {
    cleanupRecording();
    mediaRecorder = null;
    micState = "IDLE";
    if (e.name === "NotAllowedError" || e.name === "PermissionDeniedError") {
      errorEl.textContent = "Microphone permission denied. Browser settings में microphone allow करें.";
    } else {
      errorEl.textContent = `Microphone could not start: ${e.message || "unknown error"}`;
    }
    setStatus("Ready");
  }
}

mic.addEventListener("click", () => {
  if (micState === "RECORDING") stopRecording();
  else if (micState === "IDLE") startRecording();
});


form.addEventListener("submit", (e) => {
  e.preventDefault();
  const text = input.value.trim();
  if (!text) return;
  transcriptEl.textContent = text;
  input.value = "";
  ask(text);
});

langEl.addEventListener("change", () => {
  const code = speechCodes[langEl.value] || "hi-IN";
  if (sarvamTtsLanguages.has(langEl.value)) {
    supportStatus.textContent = `Sarvam STT + TTS • ${languageNames[langEl.value]}`;
  } else {
    supportStatus.textContent = `Sarvam STT • Browser TTS fallback for ${languageNames[langEl.value]}`;
  }
  renderChips();
  setStatus("Ready");
});

function renderChips() {
  chips.innerHTML = "";
  const list = examples[langEl.value] || examples.en;
  list.forEach(q => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "chip";
    b.textContent = q;
    b.onclick = () => {
      transcriptEl.textContent = q;
      ask(q);
    };
    chips.appendChild(b);
  });
}

renderChips();
if (sarvamTtsLanguages.has(langEl.value)) supportStatus.textContent = `Sarvam STT + TTS • ${languageNames[langEl.value]}`;
