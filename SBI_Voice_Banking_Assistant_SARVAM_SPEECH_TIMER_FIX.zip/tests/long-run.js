const http = require("http");

const cases = [
  ["Mera balance kitna hai?", "CHECK_BALANCE"],
  ["Meri last transaction kya thi?", "MINI_STATEMENT"],
  ["UPI payment pending hai.", "UPI_PENDING"],
  ["Nearest ATM kahan hai?", "ATM"],
  ["Saturday ko bank khula rehta hai?", "SATURDAY_BANK"],
  ["Mera debit card kho gaya hai.", "CARD_BLOCK"],
  ["Maximum kitna balance rakh sakta hoon?", "MAX_BALANCE"],
  ["NEFT kaise karte hain?", "NEFT"],
  ["Cheque bounce kyun hota hai?", "CHEQUE_BOUNCE"],
  ["KYC update kaise karu?", "KYC"],
  ["u p i", "UPI_INFO"],
  ["यू पी आई", "UPI_INFO"],
  ["ए टी एम", "ATM"],
  ["भाई account में कितने पैसे हैं", "CHECK_BALANCE"],
  ["ATM card swallowed", "ATM_RETENTION"],
  ["PIN", "PIN"],
  ["OTP", "OTP_SAFETY"]
];

function request(question, expected, i) {
  return new Promise((resolve) => {
    const body = JSON.stringify({ transcript: question, language: "hi", requestId: i });
    const req = http.request({
      hostname: "127.0.0.1", port: process.env.PORT || 5001,
      path: "/api/detect-intent", method: "POST",
      headers: {"Content-Type":"application/json","Content-Length":Buffer.byteLength(body)}
    }, (res) => {
      let data = "";
      res.on("data", c => data += c);
      res.on("end", () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ok: res.statusCode === 200 && parsed.intent === expected, actual: parsed.intent, expected});
        } catch {
          resolve({ok:false, actual:"INVALID_RESPONSE", expected});
        }
      });
    });
    req.on("error", () => resolve({ok:false, actual:"NETWORK_ERROR", expected}));
    req.end(body);
  });
}

(async () => {
  const failures = [];
  for (let i = 0; i < 100; i++) {
    const [q, expected] = cases[i % cases.length];
    const result = await request(q, expected, i + 1);
    if (!result.ok) failures.push({index:i+1, question:q, ...result});
  }
  console.log(`Long-run sequential test: ${100 - failures.length}/100 passed`);
  if (failures.length) {
    console.log("Failures:");
    for (const f of failures) console.log(`- ${f.question} | expected=${f.expected} | actual=${f.actual}`);
    process.exitCode = 1;
  }
})();
