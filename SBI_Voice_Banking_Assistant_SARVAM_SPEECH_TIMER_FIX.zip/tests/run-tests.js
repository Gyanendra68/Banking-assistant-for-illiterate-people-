const fs = require("fs");

const cases = JSON.parse(fs.readFileSync(__dirname + "/test_cases.json", "utf8"));
const base = process.env.BASE_URL || "http://127.0.0.1:5001";

async function main() {
  const health = await fetch(base + "/api/health");
  if (!health.ok) throw new Error("Server is not reachable at " + base);

  let passed = 0;
  const failures = [];
  for (const c of cases) {
    const r = await fetch(base + "/api/detect-intent", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({transcript:c.question, language:"hi"})
    });
    const d = await r.json();
    if (d.intent === c.expectedIntent) passed++;
    else failures.push({question:c.question, expected:c.expectedIntent, actual:d.intent});
  }

  console.log(`Intent regression test: ${passed}/${cases.length} passed`);
  if (failures.length) {
    console.log("\nFailures:");
    for (const x of failures) console.log(`- ${x.question} | expected=${x.expected} | actual=${x.actual}`);
    process.exitCode = 1;
  }
}
main().catch(err => { console.error(err.message); process.exitCode = 1; });
